#!/system/bin/sh
ifconfig eth0 192.168.0.253 up