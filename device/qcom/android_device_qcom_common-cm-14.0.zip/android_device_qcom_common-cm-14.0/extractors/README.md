# Qualcomm Binaries
Binary makefile generation scripts

## Graphics:
### Origins:
msm8916: 6.0.1 blobs from kipper/crackling  
msm8974: 6.0.1 blobs from bacon  
msm8992: 7.0 blobs from bullhead nrd90s  
msm8994: 7.0 blobs from angler nrd90u  
msm8996: 7.0 blobs from g5 (f700) v18g nrd90m  
### Min kernel patch level required:
msm8916: Any 5.0+ kernel  
msm8974: Any 5.1+ kernel  
msm8992: Any 6.0+ kernel  
msm8994: Any 6.0+ kernel  
msm8996: Patched mdss/kgsl up to LA.UM.5.5.r1-00100-8x96.0  
